Description: Gaia DR4 epoch astrometry data for 12 sources, pre-released in June 2026.

Detailed information: see https://www.cosmos.esa.int/web/gaia/dr4-prerelease

Data license: see https://www.cosmos.esa.int/web/gaia-users/license

Acknowledgement and citation instructions: see https://gea.esac.esa.int/archive/documentation/GDR3/Miscellaneous/sec_credit_and_citation_instructions/

